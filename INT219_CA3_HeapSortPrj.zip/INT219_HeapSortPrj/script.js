function funpvpg() {
    alert("You are still on initial page")
}

function funxtpg() {
    window.open("heapSort.html", "_self");
}

//var n;
// n = Number(document.getElementById("input1").value);
// function input1() {
//     window.alert("Use space to seperate the elements")
//     let array = prompt().split(' ');
//     let arrayLength = array.length;
//     document.getElementById('elementinpt').innerHTML += array.join(' ');
// }

//let newArray = [];

function ascending() {
    window.alert("Ascending order");

    let array = prompt().split(' ');
    let arrayLength = array.length;
    let newArray = [];

    document.getElementById('inpt').innerHTML += array.join(' ');


    function setDoughter(iter) {
        var iLeft = iter * 2 + 1;
        var iRight = iter * 2 + 2;
        var res = 0;

        if (iLeft < arrayLength - 1) {
            setDoughter(iLeft);
        }
        if (array[iLeft] < array[iRight] && array[iLeft] < array[iter]) {
            res = array[iter];
            array[iter] = array[iLeft];
            array[iLeft] = res
        }

        if (iRight < arrayLength - 1) {
            setDoughter(iRight);
        }
        if (array[iLeft] > array[iRight] && array[iRight] < array[iter]) {
            res = array[iter];
            array[iter] = array[iRight];
            array[iRight] = res;
        }

        if (array[iLeft] > array[iRight]) {
            res = array[iLeft];
            array[iLeft] = array[iRight];
            array[iRight] = res;
        }
    }

    function start() {
        var i = 0;
        while (array[0] != null) {
            setDoughter(0);
            newArray.push(array[0]);
            array.splice(0, 1);
        }
    }

    start();
    document.getElementById('otpt').innerHTML += newArray.join(' ');


}

function descending() {
    window.alert("Descending order");

    let array = prompt().split(' ');
    let arrayLength = array.length;
    let newArray = [];

    document.getElementById('inpt').innerHTML += array.join(' ');


    function setDoughter(iter) {
        var iLeft = iter * 2 + 1;
        var iRight = iter * 2 + 2;
        var res = 0;

        if (iLeft < arrayLength - 1) {
            setDoughter(iLeft);
        }
        if (array[iLeft] > array[iRight] && array[iLeft] > array[iter]) {
            res = array[iter];
            array[iter] = array[iLeft];
            array[iLeft] = res
        }

        if (iRight < arrayLength - 1) {
            setDoughter(iRight);
        }
        if (array[iLeft] < array[iRight] && array[iRight] > array[iter]) {
            res = array[iter];
            array[iter] = array[iRight];
            array[iRight] = res;
        }

        if (array[iLeft] < array[iRight]) {
            res = array[iLeft];
            array[iLeft] = array[iRight];
            array[iRight] = res;
        }
    }

    function start() {
        var i = 0;
        while (array[0] != null) {
            setDoughter(0);
            newArray.push(array[0]);
            array.splice(0, 1);
        }
    }

    start();
    document.getElementById('otpt').innerHTML += newArray.join(' ');
}

function reloadpg() {
    location.reload();
}